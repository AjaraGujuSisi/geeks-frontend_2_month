//first task
let totalScores = [40, 55, 22, 89, 14, 78, 56, 47, 59];

let convertedScores = [];

for (let i = 0; i < totalScores.length; i++) {
    let points = totalScores[i];
    let grade;

    if (points < 20) {
        grade = 1;
    } else if (points < 40) {
        grade = 2;
    } else if (points < 60) {
        grade = 3;
    } else if (points < 80) {
        grade = 4;
    } else {
        grade = 5;
    }

    convertedScores.push(grade);
}

console.log(convertedScores); // Вывод [3, 3, 2, 5, 1, 4, 3, 3, 3]


//second task
let value = parseInt(prompt("Введите число от 2 до 10:"));

if (value >= 2 && value <= 10) {
    for (let i = 1; i <= 10; i++) {
        console.log(`${value} × ${i} = ${value * i}`);
    }
} else {
    console.log("Пожалуйста, введите число от 2 до 10.");
}
