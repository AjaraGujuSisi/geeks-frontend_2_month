//Расчет бензина if else
let amount = 1000;
let fuelType = '95';

let price;

if (fuelType === '92') {
    price = 70;
} else if (fuelType === '95') {
    price = 75;
} else if (fuelType === '98') {
    price = 80;
} else if (fuelType === 'дизель') {
    price = 65;
} else if (fuelType === 'газ') {
    price = 30;
} else {
    console.log('Неверный тип топлива');
    price = 0;
}
let liters = amount / price;

console.log('Количество литров:', liters );



//Расчет бензина switch case
let amountSC = 1000;
let fuelTypeSC = '95';
let priceSC;

switch (fuelTypeSC) {
    case '92':
        priceSC = 70;
        break;
    case '95':
        priceSC = 75;
        break;
    case '98':
        priceSC = 80;
        break;
    case 'дизель':
        priceSC = 65;
        break;
    case 'газ':
        priceSC = 30;
        break;
    default:
        console.log('Неверный тип топлива');
        priceSC = 0;
}

let litersSC = amountSC / priceSC;
console.log('Количество литров:', litersSC);



//Вывод регина if else
let $regionCode = '01';

let $regionName;

if ($regionCode === '01') {
    $regionName = 'Бишкек';
} else if ($regionCode === '02') {
    $regionName = 'Ош';
} else if ($regionCode === '03') {
    $regionName = 'Джалал-Абадская область';
} else if ($regionCode === '04') {
    $regionName = 'Нарынская область';
} else if ($regionCode === '05') {
    $regionName = 'Иссык-Кульская область';
} else if ($regionCode === '06') {
    $regionName = 'Таласская область';
} else if ($regionCode === '07') {
    $regionName = 'Баткенская область';
} else if ($regionCode === '08') {
    $regionName = 'Чуйская область';
} else if ($regionCode === '09') {
    $regionName = 'Ошская область';
} else {
    $regionName = 'Неверный код региона';
}

console.log('Регион:', $regionName);



//Вывод региона switch case
let regionCode = '01';

let regionName;

switch (regionCode) {
    case '01':
        regionName = 'Бишкек';
        break;
    case '02':
        regionName = 'Ош';
        break;
    case '03':
        regionName = 'Джалал-Абадская область';
        break;
    case '04':
        regionName = 'Нарынская область';
        break;
    case '05':
        regionName = 'Иссык-Кульская область';
        break;
    case '06':
        regionName = 'Таласская область';
        break;
    case '07':
        regionName = 'Баткенская область';
        break;
    case '08':
        regionName = 'Чуйская область';
        break;
    case '09':
        regionName = 'Ошская область';
        break;
    default:
        regionName = 'Неверный код региона';
}

console.log('Регион:',regionName);
